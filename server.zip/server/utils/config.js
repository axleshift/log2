import dotenv from "dotenv";
dotenv.config();

export const RECAPTCHA_SECRET_KEY = process.env.RECAPTCHA_SECRET_KEY;
